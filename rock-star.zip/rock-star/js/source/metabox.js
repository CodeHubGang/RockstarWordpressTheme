/**
 * Admin Metabox 
 * Metabox custom jquery functions
 */
 
jQuery(document).ready(function() {
    jQuery('#rock-star-ui-tabs').tabs();
});